class UnaryOperators3
{
	public static void main(String[] args)
	{
		int no1=10;
		//System.out.println(no1+++no1);
		//System.out.println(++no1+++no1);	//error
		//System.out.println(++no1-++no1);
		//System.out.println(--no1---no1);	//error
		System.out.println(--no1+--no1);
	}
}