class BitwiseOperator1
{
	public static void main(String[] args)
	{
		int no1=10;	//1010
		int no2=2;	//0010
		System.out.println(no1&no2);	//0010
		System.out.println(no1|no2);	//1010
		System.out.println(no1^no2);	//1000
	}
}