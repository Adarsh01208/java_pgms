class UnaryOperators
{
	public static void main(String[] args)
	{
		//int no1=10;
		//System.out.println(no1++);	//it will first display the number and then increment the number
		//System.out.println(no1);

		int no2=10;
		System.out.println(++no2);	//it will first increment the number and then display the number
	}
}