class BitwiseOperator2
{
	public static void main(String[] args)
	{
		int no1=10;	//1010
		//int no2 = no1 >> 2;	//10
		int no2 = no1 << 2;	//101000
		System.out.println(no2);
	}
}