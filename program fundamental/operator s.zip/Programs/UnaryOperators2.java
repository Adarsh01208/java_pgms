class UnaryOperators2
{
	public static void main(String[] args)
	{
		int no1=10;
		System.out.println(no1);	//10
		System.out.println(no1++);	//10 -> 11
		System.out.println(++no1);	//12	
		System.out.println(no1);	//12

		int no2=10;
		System.out.println(no2);	//10
		System.out.println(no2--);	//10 -> 9
		System.out.println(--no2);	//8	
		System.out.println(no2);	//8
	}
}