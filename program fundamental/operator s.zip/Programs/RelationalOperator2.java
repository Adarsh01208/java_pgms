class RelationalOperator2
{
	public static void main(String[] args)
	{
		RelationalOperator2 ob=new RelationalOperator2();
		System.out.println(ob instanceof RelationalOperator2);
		System.out.println(ob instanceof Object);
		//System.out.println(ob instanceof String);
	}
}