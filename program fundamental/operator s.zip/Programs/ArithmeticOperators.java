class ArithmeticOperators
{
	public static void main(String[] args)
	{
		int no1=10;
		int no2=20;
		//int res=no1 + no2;
		System.out.println("result is : "+(no1+no2));
		System.out.println("result is : "+no1+no2);
	}
}