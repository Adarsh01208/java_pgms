class AssignmentOperator1
{
	public static void main(String[] args)
	{
		int no1=10;
		no1 += 5;			//no1=no1+5;
		System.out.println(no1);
	}
}