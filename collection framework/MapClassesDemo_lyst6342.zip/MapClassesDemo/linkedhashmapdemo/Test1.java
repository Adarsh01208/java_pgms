/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedhashmapdemo;

import java.util.LinkedHashMap;
/**
 *
 * @author Deepak
 */
public class Test1
{
    public static void main(String[] args)
    {
        LinkedHashMap lhm=new LinkedHashMap();
        
    }
}
