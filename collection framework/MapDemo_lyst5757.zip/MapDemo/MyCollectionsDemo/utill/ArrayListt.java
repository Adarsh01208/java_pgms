/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utill;

/**
 *
 * @author Deepak
 */
public class ArrayListt extends AbstractListt
{
    @Override
    public int indexOf(Object obj) {
        //body
        return super.indexOf(obj); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public boolean add(Object obj) {
        //body
        return super.add(obj); //To change body of generated methods, choose Tools | Templates.
    }
    
}