     #include <iostream>
     using namespace std;
     
     int main(){
     	
     	string name[3]={"adarsh","nandita","manoj"};
     	name[2]="chotu";
     	for(int i=0;i<=3;i++)
     	{
     		cout<<name[i]<<endl;
		 }
     	return 0;
     	
	 }
