
// find the area of cicrcle
#include <iostream>
using namespace std;
//#define pi 3.14
int main() {
    float r , circle , circumference;
	 cout<<"entre the radius of the circle " <<  endl;
	 cin>> r;
	 circle =3.14 *r*r;
	 cout<< "area of circle is "<<circle<< endl;
	 circumference=2*3.14*r;
	 cout<<"circumference 0f the cirle is " << circumference <<endl;
	 return 0;
}
