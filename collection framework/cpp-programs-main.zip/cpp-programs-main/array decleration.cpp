  #include <iostream>
  #include <bits/stdc++.h>
  using namespace std;
  int main (){
  	
  	
	  int a[5]={2,4,6,8,10};
	//  for (int i=0;i<5;i++)	 
	  for(int x:a)
	   {
	   	cout<<x<<endl;
	 // 	cout<<a[i]<<endl;
	  }
  	
  	return 0;
  }
