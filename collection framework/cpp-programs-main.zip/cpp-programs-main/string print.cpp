#include <iostream>

using namespace std;

int main() 
  {
  	
  	string str1,str2;
  	
  	cout<<"enter the two string"<<endl;
  	cin>>str1>>str2;
  	
  	if(str1.length()==str2.length()){
  		cout<<"given string is equal"<<endl;
	  }
	  else{
	  	
	  	cout<<"given string is not equal"<<endl;
	  }
  	
  	
	  
	   return 0;

}


