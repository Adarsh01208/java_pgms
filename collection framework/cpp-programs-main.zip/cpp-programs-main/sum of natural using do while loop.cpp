             //printing table using while loop 
      #include <iostream>

      using namespace std;

     int main()  { 

     int i,sum;

     do
     
      {
      	
	 sum=sum+i;
     i++;
     
    }
    while(i<=10);
    
    cout<<"sum of first natral no is "<<sum<<endl;
     return 0;
    }
 


