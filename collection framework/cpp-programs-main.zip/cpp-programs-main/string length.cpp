   #include <iostream>
   using namespace std;
   
   int main() {
   	 string name = "adarsh";
   	 cout<<"length"<<name.length()<<endl;
   	
   	
   	
   	
   
   
   
   return 0;
}
