  #include <iostream>

using namespace std;

int main()  { 

   int i, value = 0;

    cout<<"enter the value"<<endl;

     cin>>value;

    // for(int i=1;i<=10;i++)
     while(i<=10)
      {
	  

     cout<<endl<<value<<"*"<<i<<"="<<value*i<<endl;
     i++;
    }
     return 0;
 }



