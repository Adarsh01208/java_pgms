    #include <iostream>
    using namespace std;
    int main() {
    	
    	int i,n,sum=0;
    	cout<<"enter the integer"<<endl;
    	cin>>n;
    	for(int i=1;i<=n;i++)
    	{
    		sum=sum+i;
		}
    	
    	cout<<"sumof fist 10 natural number is "<<sum<<endl;
    	
    	return 0;
	}
