  #include <iostream>
    using namespace std;
    void check (int );
    
    int main(){
    	
    check(7);
    	return 0;
	}
      
      
      void check (int a) 
	  {
    	if (a%2==0)
    	{
    		cout<<"even";
		}
		else {
			cout<<"odd";
		}
	}
	
	

