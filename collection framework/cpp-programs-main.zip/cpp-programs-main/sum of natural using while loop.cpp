          //printing table using while loop 
      #include <iostream>

      using namespace std;

     int main()  { 

     int i,sum;

     while(i<=10)
     
      {
	 sum=sum+i;
     i++;
     
    }
    
    cout<<"sum of first natral no is "<<sum<<endl;
     return 0;
    }
 


